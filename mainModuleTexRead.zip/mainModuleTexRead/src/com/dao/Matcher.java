package com.dao;

import java.util.*;

public class Matcher {
    public Map<String, List<Location>> match(String text) {
        Map<String, List<Location>> result = new HashMap<>();
        for (String name : MainMadule_dao.NAMES) { 
            List<Location> locations = new ArrayList<>();
            int index = text.indexOf(name);
            while (index != -1) {
                int lineOffset = getLineOffset(text, index);
                Location location = new Location(lineOffset, index - lineOffset);
                locations.add(location);
                index = text.indexOf(name, index + 1);
            }
            if (!locations.isEmpty()) {
                result.put(name, locations);
            }
        }
        return result;
    }

    private int getLineOffset(String text, int index) {
        int lineOffset = 0;
        for (int i = 0; i < index; i++) {
            if (text.charAt(i) == '\n') {
                lineOffset = i + 1;
            }
        }
        return lineOffset;
    }

}
