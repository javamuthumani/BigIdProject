package com.dao;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import java.time.LocalDateTime;

import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.*;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;


public class MainMadule_dao {
    private static final String TEXT_URL = "http://norvig.com/big.txt";
    static final String[] NAMES = {"James", "John", "Robert", "Michael", "William", "David", "Richard", "Charles", "Joseph", "Thomas", "Christopher", "Daniel", "Paul", "Mark", "Donald", "George", "Kenneth", "Steven", "Edward", "Brian", "Ronald", "Anthony", "Kevin", "Jason", "Matthew", "Gary", "Timothy", "Jose", "Larry", "Jeffrey", "Frank", "Scott", "Eric", "Stephen", "Andrew", "Raymond", "Gregory", "Joshua", "Jerry", "Dennis", "Walter", "Patrick", "Peter", "Harold", "Douglas", "Henry", "Carl", "Arthur", "Ryan", "Roger"};

    
    
    public static void main(String[] args) throws IOException, InterruptedException, ExecutionException {
    	LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("ddHHmmss");
        String formattedNow = now.format(formatter);
    	String fileFormat = ""+formattedNow;
    	
    	DeleteFiles_DAO deleteeFile = new DeleteFiles_DAO();
    	deleteeFile.deleteAllFiles();
    	
        ExecutorService executor = Executors.newFixedThreadPool(100);
        List<Future<Map<String, List<Location>>>> futures = new ArrayList<>();
        Map<String, List<Location>> response = new ConcurrentHashMap<>();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new URL(TEXT_URL).openStream()))) {
            StringBuilder textBuilder = new StringBuilder();
            String line;
            int lineCount = 0;
            while ((line = reader.readLine()) != null) {
                textBuilder.append(line).append("\n");
                lineCount++;

//                if (lineCount % 1000 == 0) { // Send 1000 lines at a time
//                    String text = textBuilder.toString();
//                    Future<Map<String, List<Location>>> future = executor.submit(() -> new Matcher().match(text));
//
//                    futures.add(future);
//                    textBuilder.setLength(0);
//                }
            }
            // Process the remaining lines
            if (textBuilder.length() > 0) {
                String text = textBuilder.toString();
                Future<Map<String, List<Location>>> future = executor.submit(() -> new Matcher().match(text));
                Map<String, List<Location>> result = future.get();
                response =result;
                futures.add(future);
               
            }
        }

//        Map<String, List<Location>> aggregatedResult = new ConcurrentHashMap<>();
//        for (Future<Map<String, List<Location>>> future : futures) {
//            Map<String, List<Location>> result = future.get();
//            for (Map.Entry<String, List<Location>> entry : result.entrySet()) {
//                aggregatedResult.merge(entry.getKey(), entry.getValue(), (list1, list2) -> {
//                    list1.addAll(list2);
//                    return list1;
//                });
//            }
//        }

        executor.shutdown();
        
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        String jsonResponse = gson.toJson(response);
        System.out.print("response "+jsonResponse);
        
        // Define the path where the file will be written
        String workingDir = System.getProperty("user.dir");
        Path filePath = Paths.get(workingDir+"/webapps/ExportFiles/response_"+fileFormat+".txt");

        // Write the JSON string to the file
        try {
            Files.write(filePath, jsonResponse.getBytes());
            System.out.println("Response written to file: " + filePath.toAbsolutePath());
        } catch (IOException e) {
            System.err.println("Failed to write response to file: " + e.getMessage());
        }
    
//        new Aggregator().printResult(aggregatedResult);
    }

}
