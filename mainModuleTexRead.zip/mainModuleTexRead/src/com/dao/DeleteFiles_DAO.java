package com.dao;



import java.io.File;
import java.io.IOException;

public class DeleteFiles_DAO {
	
	public void deleteAllFiles() throws IOException
	{
		
		delete(1, ".txt"); //Delete Before two minitues on current date

	}
	private void delete(long days, String fileExtension) throws IOException 
	{
		String workingDir = System.getProperty("user.dir");
		File folder = new File(workingDir+"/webapps/ExportFiles/"); 
		if (folder.exists()) 
		{
			File[] listFiles = folder.listFiles(); 
			//long eligibleForDeletion = System.currentTimeMillis() - (days * 24 * 60 * 60 * 1000L);
			long eligibleForDeletion = System.currentTimeMillis() - (2* 60 * 1000L);
			for (File listFile : listFiles) 
			{
				if (listFile.getName().endsWith(fileExtension) && listFile.lastModified() < eligibleForDeletion) 
				{
					if (!listFile.delete())
					{
						System.out.println("Sorry Unable to Delete Files..");
					} 
					}
				}
			}
		}

}
