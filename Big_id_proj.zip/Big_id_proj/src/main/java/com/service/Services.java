package com.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import org.springframework.stereotype.Service;

import com.dao.Location;
import com.dto.TextModule_dto;

@Service
public interface Services {
	
	public Map<String, List<Location>> norvigFindcarAndLine(TextModule_dto text_dto) throws IOException, InterruptedException, ExecutionException;

}
