package com.service.impl;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dao.Location;
import com.dao.MainMadule_dao;
import com.dto.TextModule_dto;
import com.service.Services;

@Component
public class ServicesImpl implements Services{
	
	@Autowired
	private MainMadule_dao mainDaoTex;
	
	public Map<String, List<Location>> norvigFindcarAndLine(TextModule_dto text_dto) throws IOException, InterruptedException, ExecutionException {
		return mainDaoTex.norvigFindcarAndLine(text_dto);
	}

}
