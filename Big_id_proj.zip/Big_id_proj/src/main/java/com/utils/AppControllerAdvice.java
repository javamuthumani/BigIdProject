package com.utils;

import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import com.controller.TextController;
import com.dto.response.ResponseDto;

@SuppressWarnings({ "unchecked", "rawtypes" })
@ControllerAdvice(basePackageClasses = TextController.class)
public class AppControllerAdvice extends ResponseEntityExceptionHandler {

	@ExceptionHandler(InvalidInputException.class)
	public final ResponseEntity<Object> handleAllException(InvalidInputException ex, WebRequest request) {
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ResponseDto error = new ResponseDto("Server Error", details);

		return new ResponseEntity(error, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(RecordNotFoundException.class)
	public final ResponseEntity<Object> handleUserNotFoundException(RecordNotFoundException ex, WebRequest request) {
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ResponseDto error = new ResponseDto("Record Not Found", details);
		return new ResponseEntity(error, HttpStatus.NOT_FOUND);
	}

//	@Override
//	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
//		List<String> details = new ArrayList<>();
//		for(ObjectError error : ex.getBindingResult().getAllErrors()) {
//			details.add(error.getDefaultMessage());
//		}
//		ResponseDto error = new ResponseDto ("Validation Failed", details);
//		return new ResponseEntity("", HttpStatus.BAD_REQUEST);
//	}

	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,HttpHeaders headers, HttpStatus status, WebRequest request) {
		List<String> details = new ArrayList<>();
		for (ObjectError error : ex.getBindingResult().getAllErrors()) {
			details.add(error.getDefaultMessage());
		}
		ResponseDto errorResponse = new ResponseDto("Validation Failed", details);
		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}

}
