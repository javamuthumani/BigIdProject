package com.dao;

import java.util.*;


public class Aggregator {
	
//    public void printResult(Map<String, List<Location>> result) {
//    	Map<String,String> response = new HashMap<>();
//        for (Map.Entry<String, List<Location>> entry : result.entrySet()) {
//            System.out.println(entry.getKey() + "-->");
//            for (Location location : entry.getValue()) {
//            	response.put("lineOffset",""+location.getLineOffset());
//            	response.put("charOffset",""+location.getCharOffset());
////                System.out.println("[lineOffset=" + location.getLineOffset() + ", charOffset=" + location.getCharOffset() + "]");
//                System.out.println(response);
//            }
//            System.out.println();
//        }
//    }
	
//	 public List<Map<String,Map<String,String>>> printResult(Map<String, List<Location>> result) {
//			List<Map<String,Map<String,String>>> res = new ArrayList<>();
//			
//		        for (Map.Entry<String, List<Location>> entry : result.entrySet()) {
//		        	String nameKey = entry.getKey();
////		        	System.out.println("Key:"+entry.getKey()+",\n value:"+entry.getValue());
//
//		            for (Location location : entry.getValue()) {
//		            	 Map<String,Map<String,String>> response = new HashMap<>();
//		            	 Map<String,String> dataset =new HashMap<>();
//		            	dataset.put("charOffset",""+location.getCharOffset());
//		            	dataset.put("lineOffset",""+location.getLineOffset());
//		            	response.put(nameKey,dataset);
//		            	
//		            	res.add(response);
//
//		               
//		            }
//
//		        }
//		       return res;
//		    }
	
	 public List<Map<String,Map<String,String>>> printResult(Map<String, List<Location>> result) {
			List<Map<String,Map<String,String>>> res = new ArrayList<>();
			
		        for (Map.Entry<String, List<Location>> entry : result.entrySet()) {
//		        	String nameKey = entry.getKey();
//		        	System.out.println("Key:"+entry.getKey()+",\n value:"+entry.getValue());

		            for (Location location : entry.getValue()) {
		            	 Map<String,Map<String,String>> response = new HashMap<>();
		            	 Map<String,String> dataset =new HashMap<>();
		            	dataset.put("charOffset",""+location.getCharOffset());
		            	dataset.put("lineOffset",""+location.getLineOffset());
		            	response.put(entry.getKey(),dataset);
		            	
		            	res.add(response);

		               
		            }

		        }
		       return res;
		    }
}
