package com.dao;

public class Location {
	
	   private final int lineOffset;
	    private final int charOffset;

	    public Location(int lineOffset, int charOffset) {
	        this.lineOffset = lineOffset;
	        this.charOffset = charOffset;
	    }

	    public int getLineOffset() {
	        return lineOffset;
	    }

	    public int getCharOffset() {
	        return charOffset;
	    }

}
