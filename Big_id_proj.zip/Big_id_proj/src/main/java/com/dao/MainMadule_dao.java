package com.dao;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.*;
import java.util.concurrent.*;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import com.dto.TextModule_dto;

@Repository
public class MainMadule_dao {
//    private static final String TEXT_URL = "http://norvig.com/big.txt";
//    static final String[] NAMES = {"James", "John", "Robert", "Michael", "William", "David", "Richard", "Charles", "Joseph", "Thomas", "Christopher", "Daniel", "Paul", "Mark", "Donald", "George", "Kenneth", "Steven", "Edward", "Brian", "Ronald", "Anthony", "Kevin", "Jason", "Matthew", "Gary", "Timothy", "Jose", "Larry", "Jeffrey", "Frank", "Scott", "Eric", "Stephen", "Andrew", "Raymond", "Gregory", "Joshua", "Jerry", "Dennis", "Walter", "Patrick", "Peter", "Harold", "Douglas", "Henry", "Carl", "Arthur", "Ryan", "Roger"};

	 @Value("${txt.secret}")
     String value;
	 
	 @Value("${txt.tcount}")
     int T_count;
	
    public Map<String, List<Location>> norvigFindcarAndLine(TextModule_dto text_dto) throws IOException, InterruptedException, ExecutionException {

    	ExecutorService executor = Executors.newFixedThreadPool(T_count);
        List<Future<Map<String, List<Location>>>> futures = new ArrayList<>();
        
       
        Map<String, List<Location>> response = new ConcurrentHashMap<>();


        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new URL(value).openStream()))) {
            StringBuilder textBuilder = new StringBuilder();
            String line;
            int lineCount = 0;
            while ((line = reader.readLine()) != null) {
                textBuilder.append(line).append("\n");
                lineCount++;
//
//                if (lineCount % 1000 == 0) { // Send 1000 lines at a time
//                    String text = textBuilder.toString();
//                    Future<Map<String, List<Location>>> future = executor.submit(() -> new Matcher().match(text,text_dto.getNames()));
//                    futures.add(future);
//                    textBuilder.setLength(0);
//                }
            }
            
//            // Process the  lines
            if (textBuilder.length() > 0) {
                String text = textBuilder.toString();
                Future<Map<String, List<Location>>> future = executor.submit(() -> new Matcher().match(text,text_dto.getNames()));
                Map<String, List<Location>> result = future.get();
                response =result;
                futures.add(future);
            }
        }catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
        

//        Map<String, List<Location>> aggregatedResult = new ConcurrentHashMap<>();
//        for (Future<Map<String, List<Location>>> future : futures) {
//            Map<String, List<Location>> result = future.get();
//            
//            for (Map.Entry<String, List<Location>> entry : result.entrySet()) {
//                aggregatedResult.merge(entry.getKey(), entry.getValue(), (list1, list2) -> {
//                    list1.addAll(list2);
//                   
//                    return list1;
//                });
//            }
//        }

        executor.shutdown();
        

//        return new Aggregator().printResult(aggregatedResult);
        return response;
    }

}
