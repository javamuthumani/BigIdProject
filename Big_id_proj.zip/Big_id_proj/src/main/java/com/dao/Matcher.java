package com.dao;

import java.util.*;

public class Matcher {
   
	public Map<String, List<Location>> match(String text,String[] NAMES) {
        Map<String, List<Location>> result = new HashMap<>();
       
        for (String name : NAMES) { 
            List<Location> locations = new ArrayList<>();
            int index = text.indexOf(name);
            
            while (index != -1) {

            	
                int lineOffset = getLineOffset(text, index);
                Location location = new Location(lineOffset, index - lineOffset);
                locations.add(location);
                index = text.indexOf(name, index + 1);
//                System.out.println((count++)+" : "+name+" -> {");
//                System.out.println(" lineOffset => "+lineOffset+" \n},");
//                System.out.println("{\n CharOffset => "+(index - lineOffset)+" \n},");
            }
            if (!locations.isEmpty()) {
                result.put(name, locations);
            }
        }
//        System.out.println("result "+result);
        return result;
    }

    private int getLineOffset(String text, int index) {
        int lineOffset = 0;
        for (int i = 0; i < index; i++) {
            if (text.charAt(i) == '\n') {
                lineOffset = i + 1;
            }
        }
        return lineOffset;
    }

}
