package com.dto.response;

import java.util.List;


import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="error")
public class ResponseDto {
        
	
	  public ResponseDto(String message, List<String> details) {
		   super();
		   this.message = message;
		   this.description = details;
	  }
	  @JsonProperty("messageCode")
	  private String message;
	  
	  @JsonProperty("message")
	  private List<String> description;
}
