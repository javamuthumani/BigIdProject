package com.dto;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Value;

import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.validation.constraints.NotBlank;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TextModule_dto implements Serializable{
	
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3768376145450799518L;

	@NotBlank
	private String[] names;
	
	private String text_url;
	
	public String[] getNames() {
		return names;
	}
	public void setNames(String[] names) {
		this.names = names;
	}
	public String getText_url() {
		return text_url;
	}
	public void setText_url(String text_url) {
		this.text_url = text_url;
	}
	
	
	

}
